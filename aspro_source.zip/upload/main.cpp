#include "Camera.h"
#include "ImageProcessing.h"
#include "Robot.h"
#include "ThresholdRange.h"
#include "Communications.h"
#include "SoccerField.h"
#include "Algorithms.h"

#include <opencv.hpp>
#include <iostream>
#include <conio.h>

using namespace std;
using namespace cv;

void main()
{

	/*ThresholdRange *t1 = (ThresholdRange*) malloc(sizeof(ThresholdRange));
	t1->lower_bound = 30;
	t1->upper_bound = 50;
	Camera *c = new Camera();
	Robot *r1 = new Robot(1, *t1);
	ImageProcessing *processor = new ImageProcessing();
	c->selectCamera(1);
	Mat image = c->getCurrentFrame();
	Mat hsvimg(image.rows, image.cols, image.type());
	Mat h(image.rows, image.cols, CV_8UC1);
	Mat s(image.rows, image.cols, CV_8UC1);
	Mat v(image.rows, image.cols, CV_8UC1);
	Mat thresh1, thresh2;
	Mat smooth1, smooth2;
	Mat comp[3];

	namedWindow("Image");

	Point2D *point = new Point2D[2];

	while(1)
	{
		cvtColor(image, hsvimg, CV_BGR2HSV);
		split(hsvimg, comp);

		thresh1 = processor->getThresholdedImage(*comp, 70, 100);
		thresh2 = processor->getThresholdedImage(*comp, 1, 25);
		smooth1 = processor->getSmoothImage(thresh1, 1);
		smooth2 = processor->getSmoothImage(thresh2, 1);

		imshow("Image", image);


		r1->getPosition(*comp, point);
		cout << "X1=" << point->posx << ",Y1=" << point->posy << endl;
		char ch = cvWaitKey(10);
		if(ch == 'q')
		{
			break;
		}
		else
		{
			image = c->getCurrentFrame();
		}
	}*/


	/*SoccerField *sf = new SoccerField();
	Camera *cam = new Camera();
	cam->selectCamera(1);
	Mat img;

	while(true)
	{
	    img = cam->getCurrentFrame();
	    Point2D pnt = sf->getCentre(img);
	    cout << "(" << pnt.posx << "," << pnt.posy << ")" << endl;
	    char c = waitKey(200);
	    if(c=='q')
	    {
	        break;
	    }
	}*/

	SoccerField fld;
	SoccerBall ball(ThresholdRange(140, 170));
	Robot rob(1, ThresholdRange(100, 110));
	Camera cam;
	cam.selectCamera(1);
	namedWindow("Frame");
	while(true)
	{
	    Mat frm = cam.getCurrentFrame();
	    imshow("Frame", frm);
	    char ch = waitKey(200);
	    if(ch == 'c')
	    {
	        destroyWindow("Frame");
	        break;
	    }
	}
	Algorithms algo;
	algo.soccer_defend(fld, ball, rob, cam);
	//ball.getPosition();
}
