#ifndef ROBOT_H
#define ROBOT_H

#include <opencv.hpp>
#include <cvblob.h>

#include "Camera.h"
#include "ImageProcessing.h"
#include "ThresholdRange.h"
#include "Point2D.h"
#include "Robot_Interface.h"
#include "Communications.h"

using namespace cv;
using namespace cvb;
using namespace std;

class Robot : public Robot_Interface
{
private:
	ThresholdRange threshold_range;
	ImageProcessing *processor; /* image processor object */
	CvBlobs blobs; /* this will contain information about blobs detected */
	Communications *com; /* communications object */

public:
	Robot(int t, ThresholdRange range)
	{
	    /*
	    ** initialization
	    ** threshold and create objects
	    */
		this->threshold_range = ThresholdRange(100,110); /* threshold for blue colored blob */
		processor = new ImageProcessing();
		com = new Communications();
	}


    /*
    ** function to get position of robot
    ** input: currimg (current frame), pos (pointer to store position)
    ** output: none
    */
	void getPosition(Mat currimg, Point2D *pos)
	{
	    /* threshold the image */
		Mat thresh = processor->getThresholdedImage(currimg, this->threshold_range.lower_bound, this->threshold_range.upper_bound);
		/* smooth the image */
		Mat smooth = processor->getSmoothImage(thresh, 3);
		/* create an image which will have detected blobs rendered in it */
		IplImage *dispimg = cvCreateImage(cvSize(currimg.rows, currimg.cols), IPL_DEPTH_LABEL, 3);

		IplImage orig = smooth;
		/* perform labelling operation */
		cvLabel(&orig, dispimg, blobs);

        /* find label of largest blob */
        CvLabel lab = cvb::cvGreaterBlob(blobs);
        /* Filter the blobs by label. Only blobs of label lab will be present after this operation */
        cvb::cvFilterByLabel(blobs, lab);

		if(blobs.size() != 0)
		{
		    /* CvBlobs is a type of Vector, so use a constant iterator to iterate over the available blobs in the list */
		    for (CvBlobs::const_iterator it=blobs.begin(); it!=blobs.end(); ++it)
            {
                /* get x and y co-ordinates of blob given by contant_iterator it */
                pos->posx = it->second->centroid.x;
                pos->posy = it->second->centroid.y;
            }
		}
		/* release alocated images to free up memory and prevent memory leaks */
		cvReleaseImage(&dispimg);
		cvReleaseBlobs(blobs);
	}


    /*
    ** function to move forward
    ** input: none
    ** output: none
    */
	void moveForward()
	{
	    com->moveForward();
	}


	/*
    ** function to move backward
    ** input: none
    ** output: none
    */
	void moveBackward()
	{
	    com->moveBackward();
	}

};

#endif
