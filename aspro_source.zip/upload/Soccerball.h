#ifndef SOCCERBALL_H
#define SOCCERBALL_H
#include "SoccerBall_interface.h"

class SoccerBall : public SoccerBall_Interface
{
    private:
    ThresholdRange threshold_range;
	ImageProcessing *processor;
	CvBlobs blobs;

	public:
	SoccerBall(ThresholdRange range)
	{
		this->threshold_range = ThresholdRange(140,170);
		processor = new ImageProcessing();
	}

    Point2D getPosition(Mat currimg)//get centre of the ball blob
	{
	    /* this whole process is described in class Robot */
	    Point2D pos;
	    Mat thresh = processor->getThresholdedImage(currimg, this->threshold_range.lower_bound, this->threshold_range.upper_bound);//threshold image
		Mat smooth = processor->getSmoothImage(thresh, 3);//smooth image
		cvNamedWindow("fsmooth");

		IplImage *dispimg = cvCreateImage(cvSize(currimg.rows, currimg.cols), IPL_DEPTH_LABEL, 3);

		IplImage orig = smooth;
		cvShowImage("fsmooth", &orig);
		cvLabel(&orig, dispimg, blobs);

        CvLabel lab = cvb::cvGreaterBlob(blobs);

        cvb::cvFilterByLabel(blobs, lab);

		if(blobs.size() != 0)
		{
		    for (CvBlobs::const_iterator it=blobs.begin(); it!=blobs.end(); ++it)
            {
                pos.posx = it->second->centroid.x;
                pos.posy = it->second->centroid.y;
            }
		}

		cvReleaseImage(&dispimg);
		cvReleaseBlobs(blobs);
		return pos;
	}
};

#endif
