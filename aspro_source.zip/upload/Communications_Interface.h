class Communications_Interface
{
	virtual void moveForward() = 0;
	virtual void moveBackward() = 0;
};
