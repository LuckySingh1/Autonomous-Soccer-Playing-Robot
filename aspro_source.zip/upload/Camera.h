#ifndef CAMERA_H
#define CAMERA_H

#include "Camera_Interface.h"
#include <opencv.hpp>

class Camera : public Camera_Interface
{
	VideoCapture capture;
	Mat img;

public:
    /*
    ** function to select camera
    ** input: ind (index of camera to be selected. 0 - first connected camera, 1 - next connected camera and so on
    ** output: boolean result indicating whether camera was successfully selected or not
    */
	bool selectCamera(int ind)
	{
	    /* try to open specified camera */
		bool res = capture.open(ind);
		if(!res)
		{
			return false;

		}
		else
		{
			return true;
		}
	}


    /*
    ** function to get current frame from camera
    ** input: none
    ** output: current frame from camera (in Mat object)
    */
	Mat getCurrentFrame()
	{
	    /* read from capture device */
		capture.read(this->img);
		return this->img;
	}
};

#endif
