class SoccerBall_Interface
{
public:
	virtual Point2D getPosition(Mat m) = 0;
};
