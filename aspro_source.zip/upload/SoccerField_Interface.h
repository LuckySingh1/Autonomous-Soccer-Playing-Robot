class SoccerField_Interface
{
public:
	virtual Point2D getCentre() = 0;
	virtual int getLength() = 0;
	virtual int getBreadth() = 0;
};
