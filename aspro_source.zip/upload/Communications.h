#ifndef COMMUNICATIONS_H_INCLUDED
#define COMMUNICATIONS_H_INCLUDED

#include <windows.h>
#include <tchar.h>
#include "Communications_Interface.h"

class Communications : public Communications_Interface
{
    private:
    HANDLE portHandle;

public:
    Communications()
    {
        portHandle = CreateFile(_T("COM9"),  // Specify port device: default "COM1"
		GENERIC_READ | GENERIC_WRITE,       // Specify mode that open device.
		0,                                                        // the devide isn't shared.
		NULL,                                                 // the object gets a default security.
		OPEN_EXISTING,                                // Specify which action to take on file.
		0,                                                      // default.
		NULL);
    }


    /*
    ** function to check whether com port is open
    ** input: none
    ** output: boolean result indicating if COM Port is open or not
    */
    bool isOpen()
    {
        if(portHandle == INVALID_HANDLE_VALUE)
        return false;
        else
        return true;
    }


    /*
    ** function to send a command to the COM port.
    ** always check if the com port is opened by using isOpen(), before writing data
    ** input: n (integer to be written. If n > 255, only the lower byte would be transmitted)
    ** output: none
    */
    void sendCommand(int n)
    {
        DWORD nbw = 0;
        int res = WriteFile(portHandle,&n,1,&nbw,NULL);
        if(res == FALSE)
        {
            cout << "Couldnot write command!\n";
        }
        cout << "Number of bytes written:" << nbw << endl;
    }


    /*
    ** function to send forward command.
    ** input: none
    ** output: none
    */
    void moveForward()//send 'i'(119) key command
    {
        sendCommand(119);
    }


    /*
    ** function to send forward command.
    ** input: none
    ** output: none
    */
    void moveBackward()//send 'k'(115) key command
    {
        sendCommand(115);
    }

};

#endif // COMMUNICATIONS_H_INCLUDED
