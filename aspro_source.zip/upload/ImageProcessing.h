#ifndef IMAGE_PROCESSING_H
#define IMAGE_PROCESSING_H

#include <opencv.hpp>
#include <cvblob.h>

using namespace cv;
using namespace cvb;
using namespace std;

class ImageProcessing
{
public:

    /*
    ** function to get thresholded image from input image
    ** input: img (input image), lb (lower bound to be used during thresholding), hb (upper bound to be used in thresholding)
    ** output: thresholded image
    */
	Mat getThresholdedImage(Mat img, int lb, int hb)
	{
	    /* create matrices for use during processing */
		Mat retimg(img.rows, img.cols, CV_8UC1);
		Mat t1(img.rows, img.cols, CV_8UC1);
		Mat t2(img.rows, img.cols, CV_8UC1);

		/* threshold first time using lower bound */
		threshold(img, t1, hb, 255, THRESH_BINARY);
		/* threshold second time using upper bound */
		threshold(img, t2, lb, 255, THRESH_BINARY);

		subtract(t2, t1, retimg); /* subtract second thresholded image from first one */

		return retimg;
	}


    /*
    ** function to get smoothened image from input image
    ** input: img (input image), num_of_times_to_smooth (number of smoothing iterations performed)
    ** output: smoothened image
    */
	Mat getSmoothImage(Mat img, int num_times_to_smooth)
	{
	    /* create matrices for use during processing */
		Mat retimg(img.rows, img.cols, CV_8UC1);
		Mat temp(img.rows, img.cols, CV_8UC1);

		retimg = img;

		int i = 0;
		for(i=0; i<num_times_to_smooth; i++)
		{
		    /* perform median blurring */
			medianBlur(retimg, temp, 9);
			retimg = temp;
		}

		return retimg;
	}
};
#endif
