#ifndef SOCCERFIELD_H_INCLUDED
#define SOCCERFIELD_H_INCLUDED

#include <cvblob.h>

#include "SoccerField_Interface.h"

using namespace std;
using namespace cv;
using namespace cvb;

class SoccerField : public SoccerField_Interface
{
    private:
    ImageProcessing *processing; // pointer to image processing object
    int len, bdth; // previously recorded length and breadth of field

    public:

    /* function to check whether Goal point is in range of soccer field widh & height
    ** input: p (point to be checked for being in range
    ** output: boolean result indicating whether the input point is within range of soccer field
    */
    bool inRange(int p)
    {
        /* get center of soccer-field */
        Point2D fcentre = this->getCentre();
        /* get breadth of soccer-field */
        int breadth = this->getBreadth();

        /* calculate upper and lower limits of soccer field */
        int upper = fcentre.posy - breadth/2;
        int lower = fcentre.posy + breadth/2;

        /*
        ** if input point p lie in between upper and lower bounds of field,
        ** return TRUE else FALSE
        */
        if(fcentre.posy > p && p > upper)
            return true;
        else if(fcentre.posy < p && p < lower)
            return true;
        else if(fcentre.posy == p)
            return true;
        else
            return false;
    }

    SoccerField()
    {
        /* initialize new image processing object */
        processing = new ImageProcessing();
    }


    /*
    ** function to get centre of soccer field
    ** input: none
    ** output: center of soccer field in Point2D object
    */
    Point2D getCentre()
    {
        char centerx[10], centery[10];
        int a = GetPrivateProfileString("field", "centerX", "-1", centerx, 10, "D:\\projconfig.ini");
        int b = GetPrivateProfileString("field", "centerY", "-1", centery, 10, "D:\\projconfig.ini");
        int cx = atoi(centerx);
        int cy = atoi(centery);

        Point2D pnt;
        pnt.posx = cx;
        pnt.posy = cy;

        return pnt;
    }

    /*
    ** function to get length of soccer field
    ** input: none
    ** output: int value of length of soccer field
    */
    int getLength()
    {
        char centerx[10], spotlx[10];
        int a = GetPrivateProfileString("field", "centerX", "-1", centerx, 10, "D:\\projconfig.ini");
        int b = GetPrivateProfileString("field", "spotlx", "-1", spotlx, 10, "D:\\projconfig.ini");
        if(a == 0 || b == 0)
        {
            return -1;
        }
        else
        {
            int cx = atoi(centerx);
            int slx = atoi(spotlx);
            int rval = cx - slx;
            return (2*rval);
        }
    }


    /*
    ** function to get length of soccer field
    ** input: none
    ** output: int value of length of soccer field
    */
    int getBreadth()
    {
        char centery[10], spotby[10];
        int a = GetPrivateProfileString("field", "centerY", "-1", centery, 10, "D:\\projconfig.ini");
        int b = GetPrivateProfileString("field", "spotby", "-1", spotby, 10, "D:\\projconfig.ini");
        if(a == 0 || b == 0)
        {
            return -1;
        }
        else
        {
            int cy = atoi(centery);
            int sby = atoi(spotby);
            int rval = cy - sby;
            return (2*rval);
        }
    }
};


#endif // SOCCERFIELD_H_INCLUDED
