#ifndef THRESHOLD_RANGE_H
#define THRESHOLD_RANGE_H

class ThresholdRange
{
public:
	int lower_bound;
	int upper_bound;

public:
	ThresholdRange(int lb, int ub)
	{
		this->lower_bound = lb;
		this->upper_bound = ub;
	}

	ThresholdRange()
	{
		this->lower_bound = 0;
		this->upper_bound = 0;
	}
};

#endif