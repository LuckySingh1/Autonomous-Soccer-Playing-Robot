#include <opencv.hpp>

#include "Camera.h"
#include "Point2D.h"
#include "ImageProcessing.h"
#include "SoccerField.h"
#include "Robot.h"

using namespace std;
using namespace cv;
using namespace cvb;

void WriteCenter()
{
    ImageProcessing *proc = new ImageProcessing();
    Camera *c = new Camera();
    SoccerField *f = new SoccerField();
    c->selectCamera(1);
    Mat frm;
    char *str = new char[3];
    while(true)
    {
        frm = c->getCurrentFrame();
        namedWindow("Frame");
        imshow("Frame", frm);
        Point2D point;
        point = f->getCentre();
        Mat hsv(frm.rows, frm.cols, frm.type());
        cvtColor(frm, hsv, CV_BGR2HSV);
        Mat cmp[3];
        split(hsv, cmp);
        Mat th1 = proc->getThresholdedImage(cmp[2], 10, 100);
        Mat sm1 = proc->getSmoothImage(th1, 3);
        namedWindow("Smoothened");
        imshow("Smoothened", sm1);
        CvBlobs blobs;
        IplImage *disp = cvCreateImage(cvSize(frm.rows, frm.cols), IPL_DEPTH_LABEL, 3);
        IplImage smooth = sm1;
        cvLabel(&smooth, disp, blobs);
        CvLabel greatest = cvGreaterBlob(blobs);
        cvFilterByLabel(blobs, greatest);
        if(blobs.size() != 0)
		{
		    for (CvBlobs::const_iterator it=blobs.begin(); it!=blobs.end(); ++it)
            {
                //cout << "Blob #" << it->second->label << ": Area=" << it->second->area << ", Centroid=(" << it->second->centroid.x << ", " << it->second->centroid.y << ")" << endl;
                point.posx = it->second->centroid.x;
                point.posy = it->second->centroid.y;
            }
		}
        cout << "Center:(" << point.posx << "," << point.posy << ")\n";
        char ch = waitKey(100);
        if(ch == 'w')
        {
            bool r = WritePrivateProfileString("field", "centerX", itoa(point.posx, str, 10), "D:\\projconfig.ini");
            r = WritePrivateProfileString("field", "centerY", itoa(point.posy, str, 10), "D:\\projconfig.ini");
            if(!r)
                cout << "error while writing to file!\n";
                char wch = waitKey(0);
        }
        else if(ch == 'q')
        {
            break;
        }
        cvReleaseImage(&disp);
    }
    destroyAllWindows();
}

void WriteRobotDimension()
{
    Camera *c = new Camera();
    Robot robot(1, ThresholdRange(100, 110));
    c->selectCamera(1);
    Mat frm;
    char *str = new char[3];
    while(true)
    {
        frm = c->getCurrentFrame();
        Mat hsv(cvSize(frm.rows, frm.cols), frm.type());
        cvtColor(frm, hsv, CV_BGR2HSV);
        cout << "debug1\n";
        Mat comp[3];
        split(hsv, comp);
        cout << "debug 2\n";
        namedWindow("Frame");
        imshow("Frame", frm);
        Point2D *point;
        robot.getPosition(comp[0], point);
        cout << "Center:(" << point->posx << "," << point->posy << ")\n";
        char ch = waitKey(100);
        if(ch == 'w')
        {
            bool r = WritePrivateProfileString("Robot", "centerX", itoa(point->posx, str, 10), "D:\\projconfig.ini");
            r = WritePrivateProfileString("Robot", "centerY", itoa(point->posy, str, 10), "D:\\projconfig.ini");
            if(!r)
                cout << "error while writing to file!\n";
                char wch = waitKey(0);
        }
        else if(ch == 'q')
        {
            break;
        }
    }
    destroyAllWindows();
    cout << "Place a pink spot and continue ......\n";

    waitKey(0);


}

void WriteDimension(int ind)
{
    Camera *c = new Camera();
    ImageProcessing *proc = new ImageProcessing();
    c->selectCamera(1);
    char *str = new char[3];
    while(true)
    {
        Mat frm = c->getCurrentFrame();
        Mat hsvimg(frm.rows, frm.cols, frm.type());
        cvtColor(frm, hsvimg, CV_BGR2HSV);
        Point2D point_len, point_bdth;
        Mat hsvcomp[3];
        split(hsvimg, hsvcomp);

        Mat thresh_pink = proc->getThresholdedImage(hsvcomp[0], 140, 170);
        Mat thresh_blue = proc->getThresholdedImage(hsvcomp[0], 100, 110);

        Mat smooth_pink = proc->getSmoothImage(thresh_pink, 3);
        Mat smooth_blue = proc->getSmoothImage(thresh_blue, 3);

        CvBlobs blb_pink, blb_blue;

        IplImage *dispImage_pink = cvCreateImage(cvSize(smooth_pink.rows, smooth_pink.cols), IPL_DEPTH_LABEL, 3);
        IplImage *dispImage_blue = cvCreateImage(cvSize(smooth_blue.rows, smooth_blue.cols), IPL_DEPTH_LABEL, 3);
        IplImage org_pink = smooth_pink;
        IplImage org_blue = smooth_blue;

        namedWindow("Image");
        namedWindow("Smooth_Pink");
        namedWindow("Smooth_Blue");
        imshow("Image", frm);
        cvShowImage("Smooth_Pink", &org_pink);
        cvShowImage("Smooth_Blue", &org_blue);

        cvLabel(&org_pink, dispImage_pink, blb_pink);
        cvLabel(&org_blue, dispImage_blue, blb_blue);

        CvLabel pink_label = cvGreaterBlob(blb_pink);
        CvLabel blue_label = cvGreaterBlob(blb_blue);

        cvFilterByLabel(blb_pink, pink_label);
        cvFilterByLabel(blb_blue, blue_label);

        cout << "number of pink blobs detected: " << blb_pink.size() << " ";
		if(blb_pink.size() != 0)
		{
		    for (CvBlobs::const_iterator it=blb_pink.begin(); it!=blb_pink.end(); ++it)
            {
                //cout << "Blob #" << it->second->label << ": Area=" << it->second->area << ", Centroid=(" << it->second->centroid.x << ", " << it->second->centroid.y << ")" << endl;
                point_len.posx = it->second->centroid.x;
                point_len.posy = it->second->centroid.y;
            }
		}

		cout << "number of blue blobs detected: " << blb_blue.size() << endl;
		if(blb_blue.size() != 0)
		{
		    for (CvBlobs::const_iterator it=blb_blue.begin(); it!=blb_blue.end(); ++it)
            {
                //cout << "Blob #" << it->second->label << ": Area=" << it->second->area << ", Centroid=(" << it->second->centroid.x << ", " << it->second->centroid.y << ")" << endl;
                point_bdth.posx = it->second->centroid.x;
                point_bdth.posy = it->second->centroid.y;
            }
		}

        cout << "Pink:(" << point_len.posx << "," << point_len.posy << ")\t";
        cout << "Blue:(" << point_bdth.posx << "," << point_bdth.posy << ")\n";
        char ch = waitKey(100);
        if(ch == 'w' && ind == 0)
        {
            bool r = WritePrivateProfileString("field", "spotlX", itoa(point_len.posx, str, 10), "D:\\projconfig.ini");
            r = WritePrivateProfileString("field", "spotlY", itoa(point_len.posy, str, 10), "D:\\projconfig.ini");
            r = WritePrivateProfileString("field", "spotbX", itoa(point_bdth.posx, str, 10), "D:\\projconfig.ini");
            r = WritePrivateProfileString("field", "spotbY", itoa(point_bdth.posy, str, 10), "D:\\projconfig.ini");
            if(!r)
                cout << "error while writing to file!\n";
                char wch = waitKey(0);
        }
        else if(ch == 'q')
        {
            break;
        }
        else if(ch == 'w' && ind == 1)
        {
            bool r = WritePrivateProfileString("robot", "robo_range", itoa((point_bdth.posy-point_len.posy), str, 10), "D:\\projconfig.ini");
            if(!r)
                cout << "error while writing to file!\n";
                char wch = waitKey(0);
        }
        cvReleaseImage(&dispImage_pink);
        cvReleaseImage(&dispImage_blue);
        //cvReleaseImage(org_pink));
        //cvReleaseImage(&org_blue);

        cvReleaseBlobs(blb_pink);
        cvReleaseBlobs(blb_blue);
    }
    destroyAllWindows();
}

void main()
{
    WriteCenter();
    char ch = waitKey(0);
    WriteDimension(0);
    //waitKey(0);
    //WriteDimension(0);

    /*SoccerField f;
    int flen = f.getLength();
    int fbreadth = f.getBreadth();
    cout << "Length: " << flen << endl;
    cout << "Breadth: " << fbreadth << endl;*/
}
