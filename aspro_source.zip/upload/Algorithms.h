#ifndef ALGORITHMS_H
#define ALGORITHMS_H


#include <windows.h>
#include <process.h>
#include "Soccerball.h"
#include "SoccerField.h"
#include "Robot.h"



class Algorithms
{
    public:

        /*
        ** main defend algorithm
        ** SF - SoccerField object
        ** B - SoccerBall object
        ** Gk - Robot object (goal-keeper)
        ** C - Camera object
        */
        void soccer_defend(SoccerField SF, SoccerBall B, Robot Gk, Camera C)
        {
            double x1,y1,x2,y2,c,m;
            C.selectCamera(1);
            Mat f; /* this will contain the current frame from camera */
            Mat comp[3]; /* this will contain H,S,V components of the image */
            while(true)
            {
                f=C.getCurrentFrame(); /* get current frame from camera */
                Mat hsvimg(f.rows, f.cols, f.type());
                cvtColor(f, hsvimg, CV_BGR2HSV); /* Conversion from RGB colorspace to HSV colorspace */
                split(hsvimg, comp); /* split into individual components */
                Point2D p1=B.getPosition(comp[0]); /* get the co-ordinates of ball centre */
                cout << "Soccer Ball: (" << p1.posx << "," << p1.posy << ")\n";

                Sleep(200); /* sleep for 200ms */

                f=C.getCurrentFrame(); /* get a frame again */
                /* perform previous operations */
                cvtColor(f, hsvimg, CV_BGR2HSV);
                split(hsvimg, comp);
                Point2D p2=B.getPosition(comp[0]);//get co-ordinates of ball centre
                cout << "Soccer Ball (new position): (" << p2.posx << "," << p2.posy << ")\n";

                int n = p2.posy-p1.posy;//difference of y co-ordinates
                int d = p2.posx-p1.posx;//difference of x co-ordinates

                cout << "n=" << n << " d=" << d << endl; // used for debugging

                if(abs(d)<5) // if
                {
                    cout << "Ball is stationary!\n";
                }
                else
                {
                    double m = n/d;//slope of path of ball
                    cout << "m=" << m << endl;
                    c=   p2.posy-(m*p2.posx);//intercept of line equation that gives path of ball
                    cout << "c=" << c << endl;
                    int Gpt=(m*(SF.getCentre().posx - SF.getLength() / 2 )) + c;//Goal point
                    cout << "Goal Point = " << Gpt << endl;

                    //if(Gpt within Goal Range)
                    Point2D gkpos;
                    Gk.getPosition(comp[0], &gkpos);//find position co-ordinates of the goal keeper robot

                    cout << "Keeper Position: (" << gkpos.posx << "," << gkpos.posy << ")\n";


                    if(SF.inRange(Gpt) && Gpt>gkpos.posy)
                    {
                        /* if goal point is within Soccer Field AND goal point is ahead of goal keeper */
                        Gk.moveForward(); /* move forward */
                        cout << "Command: Move forward\n";
                    }
                    else if(SF.inRange(Gpt) && Gpt < gkpos.posy)
                    {
                        /* if goal point is within soccer-field AND behind goal-keeper */
                        Gk.moveBackward(); /* move backward */
                        cout << "Move backward\n";
                    }
                }
            }
        }
};

#endif
