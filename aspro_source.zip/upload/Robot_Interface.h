#ifndef ROBOT_INTERFACE_H
#define ROBOT_INTERFACE_H

class Robot_Interface
{
public:
	virtual void getPosition(Mat, Point2D*) = 0;
	virtual void moveForward() =0;
	virtual void moveBackward() = 0;
};

#endif
