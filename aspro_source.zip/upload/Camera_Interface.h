#ifndef CAMERA_INTERFACE_H
#define CAMERA_INTERFACE_H

#include <opencv.hpp>

using namespace std;
using namespace cv;

class Camera_Interface
{
public:
	virtual bool selectCamera(int camIndex) = 0;
	virtual Mat getCurrentFrame() = 0;
};

#endif