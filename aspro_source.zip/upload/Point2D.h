#ifndef POINT2D_H
#define POINT2D_H

class Point2D
{
public:
	int posx, posy;//x and y co-ordinates

	Point2D()
	{
		this->posx = 0;
		this->posy = 0;
	}
};

#endif
